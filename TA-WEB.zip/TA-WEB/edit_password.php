<?php
    session_start();

    include("functions.php");
    global $conn;

    if(isset($_POST['edit-password'])) {
        $new_password = $_POST['new_password'];
        $old_password = $_POST['old_password'];

        // Get user's old password
        $getUser = mysqli_query($conn, "SELECT password FROM user WHERE phone = '{$_SESSION['data']['phone']}';");
        $userData = mysqli_fetch_assoc($getUser);

        if (password_verify($old_password, $userData['password'])) {
            $newPassword = password_hash($new_password, PASSWORD_DEFAULT);

            $updateProfile = mysqli_query($conn, "UPDATE user SET password = '$newPassword' WHERE phone = '{$_SESSION['data']['phone']}';");

            if ($updateProfile) {
                header("Location: new_profile.php?message=update_berhasil");
                exit();
            } else {
                header("Location: edit_password.php?message=update_gagal");
                exit();
            }
        } else {
            echo "<script>
                    alert('Password lama anda salah.');
                </script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Password</title>    
    <link rel="stylesheet" href="./src/output.css">
</head>
<body>
    <div class="flex flex-col min-h-screen">
        <header class="py-2.5 px-4 md:px-6 xl:px-12 2xl:px-16">
            <div class="flex justify-between items-center">
                <a href="index.php">
                    <h5 class="bg-gradient-to-br from-[#a1887f] from-15% to-[#3e2723] to-40% text-3xl font-black uppercase bg-clip-text text-transparent">COFFEE</h5>
                </a>
                
                <!-- jika belum login maka tombolnya login/signup -->
                <?php if (!isset($_SESSION["data"])) : ?>
                    <a href="login.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Log in / Sign up</a>
                <!-- jika sudah login maka tombol menjadi logout -->
                <?php else : ?>
                    <div id="parent-dropdown" class="relative inline-block">
                        <button onclick="menuDropdown()" class="flex items-center py-3 pl-6 pr-5 border rounded-full font-medium text-sm">
                            Welcome, <span class="font-normal"><?php echo $_SESSION['data']['username']; ?></span>
                        
                            <span class="ml-2">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>
                            </span>
                        </button>

                        <div id="menu-dropdown" class="hidden absolute top-auto right-0 w-52">
                            <ul class="mt-2 p-1 bg-white shadow-md rounded-xl border">
                                <?php
                                    if($_SESSION['data']['role'] === "admin") {
                                ?>
                                    <li>
                                        <a href="dashboard.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Dashboard
                                            </button>
                                        </a>
                                    </li>
                                    
                                <?php }; ?>
                                <li>
                                    <a href="index.php">
                                        <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                        Back to home
                                    </button>
                                    </a>
                                </li>
                                <li>
                                    <div class="w-full">
                                        <a href="logout.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Logout
                                            </button>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- <a href="logout.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Logout</a> -->
                <?php endif; ?>
            </div>
        </header>

        <main class="grow max-w-screen-sm mx-auto w-full px-4 lg:px-0 py-5 md:py-6">
            <form action="" method="POST">
                <div class="flex flex-col border rounded-2xl py-5 px-7">
                    <div class="mb-4">
                        <label for="new_password" class="font-bold text-base">New password</label>

                        <div class="flex justify-between gap-x-2 items-center mt-2 border py-1.5 px-3 rounded-xl transition hover:border-gray-400">
                            <input id="new_password" type="password" class="grow text-sm outline-none" placeholder="New password" name="new_password" required>

                            <button id="show_hide_new_pass" type="button" onclick="showHideNewPassword()" class="p-1 transition hover:bg-[#eeeeee] rounded-full">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </button>
                        </div>
                    </div>   
                    
                    <div>
                        <label for="old_password" class="font-bold text-base">Old password</label>

                        <div class="flex justify-between gap-x-2 items-center mt-2 border py-1.5 px-3 rounded-xl transition hover:border-gray-400">
                            <input id="old_password" type="password" class="grow text-sm outline-none" placeholder="Old password" name="old_password" required>

                            <button id="show_hide_old_pass" type="button" onclick="showHideOldPassword()" class="p-1 transition hover:bg-[#eeeeee] rounded-full">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                                </svg>
                            </button>
                        </div>
                    </div>   
                </div>

                <div class="flex justify-end items-center gap-x-2 mt-5">
                    <a href="new_profile.php" class="py-2.5 px-5 border rounded-full text-sm font-medium hover:bg-gray-100">Cancel</a>
                    <button type="submit" name="edit-password" class="py-2.5 px-5 bg-[#723E29] rounded-full text-sm font-medium text-white">Edit password</button>
                </div>
            </form>
        </main>

        <footer class="py-3 px-12 border-t bg-[#723E29] text-white text-center text-sm">
            Copyright &#169;<span id="year"></span>
        </footer>
    </div>

    <script>
        // Show and Hide New Password Function
        const showHideNewPassword = () => {
            const passwordElement = document.querySelector("#new_password");
            const buttonShowHidePass = document.querySelector("#show_hide_new_pass");

            if (passwordElement.type === "password") {
                passwordElement.type = "text";

                buttonShowHidePass.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" /></svg>'
            } else {
                passwordElement.type = "password";

                buttonShowHidePass.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>';
            }
        };

        // Show and Hide Old Password Function
        const showHideOldPassword = () => {
            const passwordElement = document.querySelector("#old_password");
            const buttonShowHidePass = document.querySelector("#show_hide_old_pass");

            if (passwordElement.type === "password") {
                passwordElement.type = "text";

                buttonShowHidePass.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" /></svg>'
            } else {
                passwordElement.type = "password";

                buttonShowHidePass.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>';
            }
        };
    </script>
</body>
</html>