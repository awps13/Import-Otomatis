<?php

require('functions.php');
show(1);

?>