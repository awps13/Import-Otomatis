<?php
    session_start();
    include('functions.php');
    global $conn;

    $id = NULL;

    if(isset($_GET['id'])) {
        $id = $_GET['id'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Details</title>
    <link rel="stylesheet" href="./src/output.css">
</head>
<body>
<div class="flex flex-col min-h-screen">
        <header class="py-2.5 px-4 md:px-6 xl:px-12 2xl:px-16">
            <div class="flex justify-between items-center">
                <a href="index.php">
                    <h5 class="bg-gradient-to-br from-[#a1887f] from-15% to-[#3e2723] to-40% text-3xl font-black uppercase bg-clip-text text-transparent">COFFEE</h5>
                </a>

                <ul class="flex items-center gap-x-2">
                    <li>
                        <a href="new_profile.php" class="py-2.5 px-5 hover:bg-[#eeeeee] rounded-full">
                            Profile
                        </a>
                    </li>
                    <li>
                        <a href="history.php" class="py-2.5 px-5 hover:bg-[#eeeeee] rounded-full font-semibold">
                            History purchase
                        </a>
                    </li>
                    
                </ul>
                
                <!-- jika belum login maka tombolnya login/signup -->
                <?php if (!isset($_SESSION["data"])) : ?>
                    <a href="login.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Log in / Sign up</a>
                <!-- jika sudah login maka tombol menjadi logout -->
                <?php else : ?>
                    <div id="parent-dropdown" class="relative inline-block">
                        <button onclick="menuDropdown()" class="flex items-center py-3 pl-6 pr-5 border rounded-full font-medium text-sm">
                            Welcome, <span class="font-normal"><?php echo $_SESSION['data']['username']; ?></span>
                        
                            <span class="ml-2">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>
                            </span>
                        </button>

                        <div id="menu-dropdown" class="hidden absolute top-auto right-0 w-52">
                            <ul class="mt-2 p-1 bg-white shadow-md rounded-xl border">
                                <?php
                                    if($_SESSION['data']['role'] === "admin") {
                                ?>
                                    <li>
                                        <a href="dashboard.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Dashboard
                                            </button>
                                        </a>
                                    </li>
                                    
                                <?php }; ?>
                                <li>
                                    <a href="index.php">
                                        <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                        Back to home
                                    </button>
                                    </a>
                                </li>
                                <li>
                                    <div class="w-full">
                                        <a href="logout.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Logout
                                            </button>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- <a href="logout.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Logout</a> -->
                <?php endif; ?>
            </div>
        </header>

        <main class="grow max-w-screen-md mx-auto px-4 lg:px-0 py-5 md:py-6 w-full">
            <?php
                $query = mysqli_query($conn, "SELECT * FROM pembelian WHERE id = '$id' AND id_user = '{$_SESSION['data']['phone']}';");

                while($data = mysqli_fetch_assoc($query)) {
            ?>
                <div class="flex items-center">
                    <a href="new_history.php" title="Back" class="inline-flex p-2 hover:bg-[#eeeeee] rounded-full text-sm font-medium border">
                        <span>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4 md:w-5 md:h-5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
                            </svg>
                        </span>
                    </a>

                    <div class="text-base md:text-lg font-medium text-center w-full">
                        Purchase Details
                    </div>
                </div>

                <div class="mt-5 md:mt-7">
                    <div class="flex justify-between items-center">
                        <div class="text-sm md:text-base font-medium">
                            Food delivery options
                        </div>

                        <div>
                            <?php 
                                if($data['pemesanan_makanan'] === "take away") {
                                    echo "<span class='text-rose-800 text-sm md:text-base font-bold capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                } elseif ($data['pemesanan_makanan'] === "dine in") {
                                    echo "<span class='text-purple-800 text-sm md:text-base font-bold capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                } else {
                                    echo "<span class='text-blue-800 text-sm md:text-base font-bold capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                }
                            ?>
                        </div>
                    </div>

                    <div class="flex justify-between items-center mt-0.5 md:mt-1">
                        <div class="text-sm md:text-base font-medium">
                            Status
                        </div>

                        <div>
                            <span class="<?php echo ($data['status'] === "in process") ? 'text-rose-800' : (($data['status'] === "to receive") ? 'text-blue-800' : 'text-green-800'); ?> text-sm md:text-base font-bold capitalize">
                                <?php echo $data['status']; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Detail product -->
                <div class="mt-3 md:mt-5">
                    <div class="text-sm md:text-base font-medium mb-1.5">
                        Product detail
                    </div>

                    <div class="border-y py-3">
                        <div class="flex flex-col gap-y-4 max-h-40 md:max-h-52 overflow-y-auto">
                            <?php
                                $getProducts = mysqli_query($conn, "SELECT * FROM barang_dibeli WHERE id_pembelian = '{$data['id']}';");

                                while($result = mysqli_fetch_assoc($getProducts)) {
                                    $getProductDetail = mysqli_query($conn, "SELECT * FROM barang WHERE id = '{$result['id_barang']}';");

                                    while($productData = mysqli_fetch_assoc($getProductDetail)) {
                            ?>
                                    <div class="flex justify-between items-start gap-x-4">
                                        <div class="inline-flex gap-x-2">
                                            <img class="w-16 h-16 md:w-20 md:h-20 rounded-xl object-cover" src="<?php echo "./images/" . $productData['gambar']?>" alt="detail_productImg">

                                            <div>
                                                <div class="text-sm md:text-base line-clamp-3">
                                                    <?= $productData['nama']; ?>
                                                </div>

                                                <div class="text-sm md:text-base text-gray-500">
                                                    <?= "({$result['jumlah']} x {$productData['harga']})"; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="text-base md:text-lg">
                                            Total: <br>

                                            <span class="font-bold">
                                                Rp <?= $productData['harga'] * $result['jumlah'] ?>
                                            </span>
                                        </div>
                                    </div>
                            <?php
                                    }
                                }
                            ?>
                        </div>
                    </div>
                </div>
            <?php
                }
            ?>
        </main>

        <footer class="py-3 px-12 border-t bg-[#723E29] text-white text-center text-base">
            Copyright &#169;<span id="year"></span>
        </footer>
    </div>
</body>
</html>