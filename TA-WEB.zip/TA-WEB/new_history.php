<?php
    session_start();

    include('functions.php');
    include('session.php');

    global $conn;
    
    $key = false;

    if(!isset($_GET['key']) || $_GET['key'] === 'all'){
        $key = false;
    }else{
        $key = $_GET['key'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History</title>    
    <link rel="stylesheet" href="./src/output.css">
</head>
<body>
    <div class="flex flex-col min-h-screen">
        <header class="py-2.5 px-4 md:px-6 xl:px-12 2xl:px-16">
            <div class="flex justify-between items-center">
                <a href="index.php">
                    <h5 class="bg-gradient-to-br from-[#a1887f] from-15% to-[#3e2723] to-40% text-3xl font-black uppercase bg-clip-text text-transparent">COFFEE</h5>
                </a>

                <ul class="flex items-center gap-x-2">
                    <li>
                        <a href="new_profile.php" class="py-2.5 px-5 hover:bg-[#eeeeee] rounded-full">
                            Profile
                        </a>
                    </li>
                    <li>
                        <a href="history.php" class="py-2.5 px-5 hover:bg-[#eeeeee] rounded-full font-semibold">
                            History purchase
                        </a>
                    </li>
                    
                </ul>
                
                <!-- jika belum login maka tombolnya login/signup -->
                <?php if (!isset($_SESSION["data"])) : ?>
                    <a href="login.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Log in / Sign up</a>
                <!-- jika sudah login maka tombol menjadi logout -->
                <?php else : ?>
                    <div id="parent-dropdown" class="relative inline-block">
                        <button onclick="menuDropdown()" class="flex items-center py-3 pl-6 pr-5 border rounded-full font-medium text-sm">
                            Welcome, <span class="font-normal"><?php echo $_SESSION['data']['username']; ?></span>
                        
                            <span class="ml-2">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>
                            </span>
                        </button>

                        <div id="menu-dropdown" class="hidden absolute top-auto right-0 w-52">
                            <ul class="mt-2 p-1 bg-white shadow-md rounded-xl border">
                                <?php
                                    if($_SESSION['data']['role'] === "admin") {
                                ?>
                                    <li>
                                        <a href="dashboard.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Dashboard
                                            </button>
                                        </a>
                                    </li>
                                    
                                <?php }; ?>
                                <li>
                                    <a href="index.php">
                                        <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                        Back to home
                                    </button>
                                    </a>
                                </li>
                                <li>
                                    <div class="w-full">
                                        <a href="logout.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Logout
                                            </button>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- <a href="logout.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Logout</a> -->
                <?php endif; ?>
            </div>
        </header>

        <main class="grow max-w-screen-lg mx-auto px-4 lg:px-0 py-5 md:py-6 w-full">
            <ul class="flex items-center gap-x-2 overflow-x-auto">
                <li>
                    <?php if((!isset($_GET['key'])) || ($_GET['key'] === 'all')): ?>
                        <a href="new_history.php?key=all">
                            <button class="py-2 px-4 border bg-gray-200 font-semibold rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                All 
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button>
                        </a>
                    <?php else: ?>
                        <a href="new_history.php?key=all">
                            <button class="py-2 px-4 border rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                All 
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if((!isset($_GET['key'])) || ($_GET['key'] !== 'in process')): ?>
                        <a href="new_history.php?key=in process">
                            <button class="py-2 px-4 border rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                In process
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}' AND status = 'in process';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button>
                        </a>
                    <?php else: ?>
                        <a href="new_history.php?key=in process">
                            <button class="py-2 px-4 border bg-gray-200 font-semibold rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                In process
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}' AND status = 'in process';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button> 
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if((!isset($_GET['key'])) || ($_GET['key'] !== 'to receive')): ?>
                        <a href="new_history.php?key=to receive">
                            <button class="py-2 px-4 border rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                To receive 
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}' AND status = 'to receive';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button>
                        </a>
                    <?php else: ?>
                        <a href="new_history.php?key=to receive">
                            <button class="py-2 px-4 border bg-gray-200 font-semibold rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                To receive 
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}' AND status = 'to receive';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button>
                        </a>
                    <?php endif; ?>
                </li>
                <li>
                    <?php if((!isset($_GET['key'])) || ($_GET['key'] !== 'completed')): ?>
                        <a href="new_history.php?key=completed">
                            <button class="py-2 px-4 border rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                Completed 
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}' AND status = 'completed';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button>
                        </a>
                    <?php else: ?>
                        <a href="new_history.php?key=completed">
                            <button class="py-2 px-4 border bg-gray-200 font-semibold rounded-full text-sm whitespace-nowrap transition duration-300 active:scale-90">
                                Completed 
                                <?php
                                    $getCountAll = mysqli_query($conn, "SELECT COUNT(*) AS count FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}' AND status = 'completed';");

                                    while($count = mysqli_fetch_assoc($getCountAll)) {
                                        echo "({$count['count']})";
                                    }
                                ?>
                            </button>
                        </a>
                    <?php endif; ?>
                </li>
            </ul>

            <div class="flex flex-col gap-y-4 mt-6">
                <?php 
                    if($key === false) {
                        $query = mysqli_query($conn, "SELECT * FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}';");

                        while($data = mysqli_fetch_assoc($query)) {
                ?>
                        <div class="border rounded-2xl py-4 px-5">
                            <div class="flex justify-end items-center gap-x-2">
                                <?php
                                    if($data['pemesanan_makanan'] === "take away") {
                                        echo "<span class='bg-rose-100 text-rose-800 text-xs font-medium py-1 px-2 rounded-full capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                    } elseif ($data['pemesanan_makanan'] === "dine in") {
                                        echo "<span class='bg-purple-100 text-purple-800 text-xs font-medium py-1 px-2 rounded-full capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                    } else {
                                        echo "<span class='bg-blue-100 text-blue-800 text-xs font-medium py-1 px-2 rounded-full capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                    }
                                ?>

                                <span class="<?php echo ($data['status'] === "in process") ? 'bg-rose-100 text-rose-800' : (($data['status'] === "to receive") ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'); ?> text-xs font-medium py-1 px-2 rounded-full capitalize">
                                    <?php echo $data['status']; ?>
                                </span>
                            </div>

                            <div class="flex flex-wrap md:flex-nowrap justify-between gap-x-6 mt-4">
                                <div class="flex -space-x-4 rtl:space-x-reverse">
                                    <?php
                                        // Menghitung jumlah gambar yang ada
                                        $countQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM barang_dibeli WHERE id_pembelian = '{$data['id']}'");
                                        $countResult = mysqli_fetch_assoc($countQuery);
                                        $imageCount = $countResult['total'];

                                        // Mengambil gambar-gambar
                                        $getImageQuery = mysqli_query($conn, "SELECT b.gambar
                                                                            FROM barang_dibeli bd
                                                                            INNER JOIN barang b ON bd.id_barang = b.id
                                                                            WHERE bd.id_pembelian = '{$data['id']}'
                                                                            LIMIT 2");

                                        // Menampilkan gambar-gambar
                                        while ($image = mysqli_fetch_assoc($getImageQuery)) {
                                            echo "<img class='w-16 h-16 md:w-24 md:h-24 border-2 border-white rounded-xl object-cover' src='./images/{$image['gambar']}' alt=''>";
                                        }

                                        // Jika jumlah gambar lebih dari 2, tampilkan tag <a> dengan jumlah gambar yang tersisa
                                        if ($imageCount > 2) {
                                            $remainingImages = $imageCount - 2;
                                            echo "<a class='flex items-center justify-center w-16 h-16 md:w-24 md:h-24 text-sm font-medium text-white bg-gray-700 border-2 border-white rounded-xl hover:bg-gray-600' href='#'>+$remainingImages</a>";
                                        }
                                    ?>
                                </div>

                                <div class="grow order-last md:order-none mt-4 md:mt-0">
                                    <div>
                                        Recipient name : <?= $data['nama']; ?>
                                    </div>
                                    <div>
                                        Phone number: <?= $data['phone'] !== '' ? $data['phone'] : '-'; ?>
                                    </div>
                                    <div>
                                        Delivery address: <?= $data['alamat'] !== '' ? $data['alamat'] : '-'; ?>
                                    </div>
                                </div>
                                
                                <div class="py-3 border-l"></div>

                                <div class="pr-0 md:pr-16">
                                    Total Belanja <br>
                                    <span class="font-semibold">
                                        <?php
                                            $getTotal = "SELECT * FROM barang_dibeli WHERE id_pembelian = '{$data['id']}'";
                                            $getTotalQuery = mysqli_query($conn, $getTotal);
    
                                            $total = 0;
                                        
                                            while($bd = mysqli_fetch_assoc($getTotalQuery)) {
                                                $getProductData = "SELECT * FROM barang WHERE id = '{$bd['id_barang']}'";
                                                $getProductDataQuery = mysqli_query($conn, $getProductData);
                                        
                                                while($productData = mysqli_fetch_array($getProductDataQuery)) {
                                                    $total += $bd['jumlah'] * $productData['harga'];
                                                }
                                            }
    
                                            echo "Rp $total";
                                        ?>
                                    </span>
                                </div>
                            </div>

                            <div class="flex justify-end items-center gap-x-2 mt-7">
                                <button class="py-2 px-4 border text-sm font-medium rounded-full hover:bg-gray-100 transition duration-300 active:scale-90">
                                    Give a review
                                </button>
                                <a href="purchase_details.php?id=<?= $data['id']; ?>">
                                    <button class="py-2 px-4 bg-[#723E29] text-sm text-white font-medium rounded-full transition duration-300 active:scale-90">
                                        Purchase details
                                    </button>
                                </a>
                            </div>
                        </div>
                <?php
                        }
                    } else {
                        $query = mysqli_query($conn, "SELECT * FROM pembelian WHERE id_user = '{$_SESSION['data']['phone']}' AND status = '$key';");

                        while($data = mysqli_fetch_assoc($query)) {
                ?>
                        <div class="border rounded-2xl py-4 px-5">
                            <div class="flex justify-end items-center gap-x-2">
                                <?php
                                    if($data['pemesanan_makanan'] === "take away") {
                                        echo "<span class='bg-rose-100 text-rose-800 text-xs font-medium py-1 px-2 rounded-full capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                    } elseif ($data['pemesanan_makanan'] === "dine in") {
                                        echo "<span class='bg-purple-100 text-purple-800 text-xs font-medium py-1 px-2 rounded-full capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                    } else {
                                        echo "<span class='bg-blue-100 text-blue-800 text-xs font-medium py-1 px-2 rounded-full capitalize'>" . $data['pemesanan_makanan'] . "</span>";
                                    }
                                ?>

                                <span class="<?php echo ($data['status'] === "in process") ? 'bg-rose-100 text-rose-800' : (($data['status'] === "to receive") ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'); ?> text-xs font-medium py-1 px-2 rounded-full capitalize">
                                    <?php echo $data['status']; ?>
                                </span>
                            </div>

                            <div class="flex flex-wrap md:flex-nowrap justify-between gap-x-6 mt-4">
                                <div class="flex -space-x-4 rtl:space-x-reverse">
                                <?php
                                    // Menghitung jumlah gambar yang ada
                                    $countQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM barang_dibeli WHERE id_pembelian = '{$data['id']}'");
                                    $countResult = mysqli_fetch_assoc($countQuery);
                                    $imageCount = $countResult['total'];

                                    // Mengambil gambar-gambar
                                    $getImageQuery = mysqli_query($conn, "SELECT b.gambar
                                                                        FROM barang_dibeli bd
                                                                        INNER JOIN barang b ON bd.id_barang = b.id
                                                                        WHERE bd.id_pembelian = '{$data['id']}'
                                                                        LIMIT 2");

                                    // Menampilkan gambar-gambar
                                    while ($image = mysqli_fetch_assoc($getImageQuery)) {
                                        echo "<img class='w-16 h-16 md:w-24 md:h-24 border-2 border-white rounded-xl object-cover' src='./images/{$image['gambar']}' alt=''>";
                                    }

                                    // Jika jumlah gambar lebih dari 2, tampilkan tag <a> dengan jumlah gambar yang tersisa
                                    if ($imageCount > 2) {
                                        $remainingImages = $imageCount - 2;
                                        echo "<a class='flex items-center justify-center w-16 h-16 md:w-24 md:h-24 text-sm font-medium text-white bg-gray-700 border-2 border-white rounded-xl hover:bg-gray-600' href='#'>+$remainingImages</a>";
                                    }
                                ?>
                                </div>

                                <div class="grow order-last md:order-none mt-4 md:mt-0">
                                    <div>
                                        Recipient name : <?= $data['nama']; ?>
                                    </div>
                                    <div>
                                        Phone number: <?= $data['phone'] !== '' ? $data['phone'] : '-'; ?>
                                    </div>
                                    <div>
                                        Delivery address: <?= $data['alamat'] !== '' ? $data['alamat'] : '-'; ?>
                                    </div>
                                </div>
                                
                                <div class="py-3 border-l"></div>

                                <div class="pr-0 md:pr-16">
                                    Total Belanja <br>
                                    <span class="font-semibold">
                                        <?php
                                            $getTotal = "SELECT * FROM barang_dibeli WHERE id_pembelian = '{$data['id']}'";
                                            $getTotalQuery = mysqli_query($conn, $getTotal);
    
                                            $total = 0;
                                        
                                            while($bd = mysqli_fetch_assoc($getTotalQuery)) {
                                                $getProductData = "SELECT * FROM barang WHERE id = '{$bd['id_barang']}'";
                                                $getProductDataQuery = mysqli_query($conn, $getProductData);
                                        
                                                while($productData = mysqli_fetch_array($getProductDataQuery)) {
                                                    $total += $bd['jumlah'] * $productData['harga'];
                                                }
                                            }
    
                                            echo "Rp $total";
                                        ?>
                                    </span>
                                </div>
                            </div>

                            <div class="flex justify-end items-center gap-x-2 mt-7">
                                <button class="py-2 px-4 border text-sm font-medium rounded-full hover:bg-gray-100 transition duration-300 active:scale-90">
                                    Give a review
                                </button>
                                <a href="purchase_details.php?id=<?= $data['id']; ?>">
                                    <button class="py-2 px-4 bg-[#723E29] text-sm text-white font-medium rounded-full transition duration-300 active:scale-90">
                                        Purchase details
                                    </button>
                                </a>
                            </div>
                        </div>
                <?php
                        }
                    }
                ?>
            </div>
        </main>

        <footer class="py-3 px-12 border-t bg-[#723E29] text-white text-center text-base">
            Copyright &#169;<span id="year"></span>
        </footer>
    </div>
</body>
</html>