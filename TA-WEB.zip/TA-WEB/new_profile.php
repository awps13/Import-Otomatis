<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>    
    <link rel="stylesheet" href="./src/output.css">
</head>
<body>
    <div class="flex flex-col min-h-screen">
        <header class="py-2.5 px-4 md:px-6 xl:px-12 2xl:px-16">
            <div class="flex justify-between items-center">
                <a href="index.php">
                    <h5 class="bg-gradient-to-br from-[#a1887f] from-15% to-[#3e2723] to-40% text-3xl font-black uppercase bg-clip-text text-transparent">COFFEE</h5>
                </a>

                <ul class="flex items-center gap-x-2">
                    <li>
                        <a href="new_profile.php" class="py-2.5 px-5 hover:bg-[#eeeeee] rounded-full font-semibold">
                            Profile
                        </a>
                    </li>
                    <li>
                        <a href="history.php" class="py-2.5 px-5 hover:bg-[#eeeeee] rounded-full">
                            History purchase
                        </a>
                    </li>
                    
                </ul>
                
                <!-- jika belum login maka tombolnya login/signup -->
                <?php if (!isset($_SESSION["data"])) : ?>
                    <a href="login.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Log in / Sign up</a>
                <!-- jika sudah login maka tombol menjadi logout -->
                <?php else : ?>
                    <div id="parent-dropdown" class="relative inline-block">
                        <button onclick="menuDropdown()" class="flex items-center py-3 pl-6 pr-5 border rounded-full font-medium text-sm">
                            Welcome, <span class="font-normal"><?php echo $_SESSION['data']['username']; ?></span>
                        
                            <span class="ml-2">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                                </svg>
                            </span>
                        </button>

                        <div id="menu-dropdown" class="hidden absolute top-auto right-0 w-52">
                            <ul class="mt-2 p-1 bg-white shadow-md rounded-xl border">
                                <?php
                                    if($_SESSION['data']['role'] === "admin") {
                                ?>
                                    <li>
                                        <a href="dashboard.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Dashboard
                                            </button>
                                        </a>
                                    </li>
                                    
                                <?php }; ?>
                                <li>
                                    <a href="index.php">
                                        <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                        Back to home
                                    </button>
                                    </a>
                                </li>
                                <li>
                                    <div class="w-full">
                                        <a href="logout.php">
                                            <button class="py-2 pl-3.5 w-full hover:bg-[#eeeeee] text-left rounded-lg">
                                                Logout
                                            </button>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- <a href="logout.php" class="py-3 px-6 bg-[#723E29] text-sm text-white font-medium rounded-full">Logout</a> -->
                <?php endif; ?>
            </div>
        </header>

        <main class="grow max-w-screen-sm mx-auto w-full px-4 lg:px-0 py-5 md:py-6">
            <div class="border rounded-2xl py-5 px-7">
                <div class="flex justify-between">
                    <div>
                        <div class="font-bold text-base">Phone number</div>
                        <div class="mt-0.5 line-clamp-2"><?php echo $_SESSION['data']['phone']?></div>
                    </div>
                    
                    <div>
                        <a href="new_profile_edit.php" class="py-2.5 px-5 border rounded-full text-sm font-medium hover:bg-gray-100">Edit data</a>
                    </div>
                </div>

                <div class="font-bold text-base mt-4">Username</div>
                <div class="mt-0.5 line-clamp-2"><?php echo $_SESSION['data']['username']?></div>

                <div class="font-bold text-base mt-4">Address</div>
                <div class="mt-0.5 line-clamp-3"><?php echo $_SESSION['data']['alamat']?></div>
            </div>

            <div class="flex justify-between border rounded-2xl py-5 px-7 mt-4">
                <div>
                    <div class="font-bold text-base">Password</div>
                    <div class="mt-0.5">**********</div>
                </div>
                
                <div>
                    <a href="edit_password.php" class="py-2.5 px-5 border rounded-full text-sm font-medium hover:bg-gray-100">
                        Edit password
                    </a>
                </div>
            </div>
        </main>

        <footer class="py-3 px-12 border-t bg-[#723E29] text-white text-center text-base">
            Copyright &#169;<span id="year"></span>
        </footer>
    </div>
</body>
</html>